public class Main {
    public static void main(String[] args) {
        char symbol = 'G';
        System.out.println(symbol);
        int size = 89;
        System.out.println(size);
        byte age = 4;
        System.out.println(age);
        short number = 56;
        System.out.println(number);
        float corner = 4.7333436f;
        System.out.println(corner);
        double anothercorner = 4.355453532;
        System.out.println(anothercorner);
        long km = 12121;
        System.out.println(km);

        byte numberone = 7;
        System.out.println(numberone);
        byte numbertwo = 5;
        System.out.println(numbertwo);
        byte numberthree = 6;
        System.out.println(numberthree);



        short a = 32767;
        System.out.println(a + 1);

        byte E = 98;
        byte C = 115;
        System.out.println(E * C);



        short Y = 153;
        float X = 5.369f;
        System.out.println(Y * X);



        char T = 'A';
        System.out.println(T);
        System.out.println(T + 1);




    }
}